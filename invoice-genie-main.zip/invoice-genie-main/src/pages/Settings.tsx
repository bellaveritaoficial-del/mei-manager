import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Building2,
  Bell,
  Palette,
  Shield,
  Sparkles,
  Cloud,
} from "lucide-react";

const Settings = () => {
  return (
    <MainLayout>
      <div className="space-y-6 max-w-3xl">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Configurações</h1>
          <p className="text-muted-foreground mt-1">
            Gerencie as preferências do sistema
          </p>
        </div>

        {/* Cloud Alert */}
        <Alert className="border-primary/20 bg-primary/5">
          <Cloud className="h-4 w-4 text-primary" />
          <AlertTitle className="text-primary">Lovable Cloud</AlertTitle>
          <AlertDescription className="text-muted-foreground">
            Habilite o Lovable Cloud para salvar dados, usar autenticação e
            leitura de NF por IA. Configure nas integrações do projeto.
          </AlertDescription>
        </Alert>

        {/* Company Settings */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Building2 className="w-5 h-5 text-primary" />
              Dados da Empresa
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="razaoSocial">Razão Social</Label>
                <Input
                  id="razaoSocial"
                  placeholder="Sua Empresa LTDA"
                  defaultValue="EMPRESA MODELO LTDA"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cnpj">CNPJ</Label>
                <Input
                  id="cnpj"
                  placeholder="00.000.000/0001-00"
                  defaultValue="12.345.678/0001-90"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ie">Inscrição Estadual</Label>
                <Input
                  id="ie"
                  placeholder="000.000.000.000"
                  defaultValue="123.456.789.012"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="telefone">Telefone</Label>
                <Input
                  id="telefone"
                  placeholder="(00) 0000-0000"
                  defaultValue="(11) 1234-5678"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="endereco">Endereço</Label>
              <Input
                id="endereco"
                placeholder="Rua, Número - Bairro"
                defaultValue="Rua das Flores, 123 - Centro"
              />
            </div>
            <Button>Salvar Alterações</Button>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Bell className="w-5 h-5 text-primary" />
              Notificações
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-foreground">Notas Vencidas</p>
                <p className="text-sm text-muted-foreground">
                  Receber alertas de notas vencidas
                </p>
              </div>
              <Switch defaultChecked />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-foreground">Novas Notas</p>
                <p className="text-sm text-muted-foreground">
                  Notificar quando novas NF forem processadas
                </p>
              </div>
              <Switch defaultChecked />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-foreground">Resumo Semanal</p>
                <p className="text-sm text-muted-foreground">
                  Receber relatório financeiro semanal
                </p>
              </div>
              <Switch />
            </div>
          </CardContent>
        </Card>

        {/* AI Settings */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Sparkles className="w-5 h-5 text-primary" />
              Inteligência Artificial
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-foreground">Leitura Automática</p>
                <p className="text-sm text-muted-foreground">
                  IA lê e preenche dados da NF automaticamente
                </p>
              </div>
              <Switch disabled />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-foreground">
                  Análise Financeira
                </p>
                <p className="text-sm text-muted-foreground">
                  IA analisa e sugere melhorias financeiras
                </p>
              </div>
              <Switch disabled />
            </div>
            <p className="text-sm text-muted-foreground bg-muted/50 p-3 rounded-lg">
              Funcionalidades de IA requerem Lovable Cloud habilitado.
            </p>
          </CardContent>
        </Card>

        {/* Security */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Shield className="w-5 h-5 text-primary" />
              Segurança
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-foreground">
                  Autenticação de Dois Fatores
                </p>
                <p className="text-sm text-muted-foreground">
                  Adicione uma camada extra de segurança
                </p>
              </div>
              <Button variant="outline" disabled>
                Configurar
              </Button>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-foreground">
                  Backup Automático
                </p>
                <p className="text-sm text-muted-foreground">
                  Backup diário dos seus dados
                </p>
              </div>
              <Switch disabled />
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
};

export default Settings;
