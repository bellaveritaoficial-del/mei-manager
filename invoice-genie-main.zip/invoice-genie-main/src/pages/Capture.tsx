import { MainLayout } from "@/components/layout/MainLayout";
import { CameraCapture } from "@/components/capture/CameraCapture";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Sparkles, Camera } from "lucide-react";

const Capture = () => {
  return (
    <MainLayout>
      <div className="space-y-6 max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-foreground">Capturar NF</h1>
          <p className="text-muted-foreground mt-1">
            Tire uma foto da nota fiscal para registro automático
          </p>
        </div>

        {/* AI Info Alert */}
        <Alert className="border-primary/20 bg-primary/5">
          <Sparkles className="h-4 w-4 text-primary" />
          <AlertTitle className="text-primary">Leitura com IA</AlertTitle>
          <AlertDescription className="text-muted-foreground">
            Habilite o Lovable Cloud para que a IA leia automaticamente os dados
            da nota fiscal e preencha todos os campos.
          </AlertDescription>
        </Alert>

        {/* Camera Card */}
        <Card className="border-border shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Camera className="w-5 h-5 text-primary" />
              Captura de Imagem
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CameraCapture
              onCapture={(imageData) => {
                console.log("Image captured:", imageData.slice(0, 50) + "...");
              }}
            />
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-lg text-foreground">Dicas</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">1.</span>
                Posicione a nota fiscal em uma superfície plana
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">2.</span>
                Certifique-se de que há boa iluminação
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">3.</span>
                Capture toda a nota fiscal na imagem
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">4.</span>
                Evite reflexos e sombras sobre o documento
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
};

export default Capture;
