import { MainLayout } from "@/components/layout/MainLayout";
import { StatCard } from "@/components/dashboard/StatCard";
import { RecentInvoices } from "@/components/dashboard/RecentInvoices";
import { FinancialChart } from "@/components/dashboard/FinancialChart";
import { mockInvoices, mockFinancialSummary } from "@/data/mockInvoices";
import {
  FileText,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Wallet,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const Index = () => {
  const navigate = useNavigate();

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  return (
    <MainLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Visão geral das suas notas fiscais e finanças
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Saldo Atual"
            value={formatCurrency(mockFinancialSummary.saldo)}
            icon={<Wallet className="w-6 h-6" />}
            variant="success"
            trend={{ value: 12.5, isPositive: true }}
          />
          <StatCard
            title="Total Receitas"
            value={formatCurrency(mockFinancialSummary.totalReceitas)}
            icon={<TrendingUp className="w-6 h-6" />}
            variant="default"
          />
          <StatCard
            title="Notas Pagas"
            value={mockFinancialSummary.notasPagas}
            icon={<CheckCircle className="w-6 h-6" />}
            variant="default"
          />
          <StatCard
            title="Notas Pendentes"
            value={mockFinancialSummary.notasPendentes}
            icon={<AlertCircle className="w-6 h-6" />}
            variant="warning"
          />
        </div>

        {/* Charts and Recent */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <FinancialChart />
          <RecentInvoices
            invoices={mockInvoices}
            onSelect={(invoice) => navigate(`/notas/${invoice.id}`)}
          />
        </div>
      </div>
    </MainLayout>
  );
};

export default Index;
