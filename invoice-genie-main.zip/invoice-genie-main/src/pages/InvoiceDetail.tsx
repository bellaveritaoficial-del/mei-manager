import { useParams, useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { InvoiceDANFE } from "@/components/invoice/InvoiceDANFE";
import { mockInvoices } from "@/data/mockInvoices";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Download, Printer, Edit } from "lucide-react";

const InvoiceDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const invoice = mockInvoices.find((inv) => inv.id === id);

  if (!invoice) {
    return (
      <MainLayout>
        <div className="flex flex-col items-center justify-center min-h-[50vh]">
          <h2 className="text-2xl font-bold text-foreground mb-2">
            Nota não encontrada
          </h2>
          <p className="text-muted-foreground mb-4">
            A nota fiscal solicitada não existe.
          </p>
          <Button onClick={() => navigate("/notas")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar para lista
          </Button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                NF-e {invoice.numero}
              </h1>
              <p className="text-muted-foreground">
                {invoice.naturezaOperacao}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Printer className="w-4 h-4 mr-2" />
              Imprimir
            </Button>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Exportar
            </Button>
            <Button size="sm">
              <Edit className="w-4 h-4 mr-2" />
              Editar
            </Button>
          </div>
        </div>

        {/* DANFE */}
        <InvoiceDANFE invoice={invoice} />
      </div>
    </MainLayout>
  );
};

export default InvoiceDetail;
